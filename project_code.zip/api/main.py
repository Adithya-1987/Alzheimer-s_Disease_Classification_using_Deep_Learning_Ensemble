"""
api/main.py
===========
FastAPI backend for Alzheimer's MRI Classification.

Endpoints:
  GET  /health   — health check
  POST /predict  — upload MRI image, returns prediction + probabilities
"""

import os
import sys
import numpy as np
import cv2
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware

# Allow imports from project root
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from preprocessing.preprocess import preprocess_image

# ─── Constants ────────────────────────────────────────────────────────────────
CLASS_NAMES = ["MildDemented", "ModerateDemented", "NonDemented", "VeryMildDemented"]
MODEL_PATH = os.path.join(os.path.dirname(__file__), "..", "saved_models", "final_model.keras")
IMG_SIZE = (224, 224)

# ─── App ──────────────────────────────────────────────────────────────────────
app = FastAPI(title="Alzheimer's MRI Classifier API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Model (loaded once at startup) ──────────────────────────────────────────
model = None


@app.on_event("startup")
def load_model():
    global model
    import tensorflow as tf

    if not os.path.exists(MODEL_PATH):
        print(f"[WARNING] Model file not found at {MODEL_PATH}. /predict will be unavailable.")
        return
    model = tf.keras.models.load_model(MODEL_PATH)
    print(f"[INFO] Model loaded from {MODEL_PATH}")


# ─── Endpoints ────────────────────────────────────────────────────────────────
@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded. Place final_model.keras in saved_models/.")

    # Read uploaded image bytes
    contents = await file.read()
    file_bytes = np.frombuffer(contents, np.uint8)
    img_bgr = cv2.imdecode(file_bytes, cv2.IMREAD_COLOR)
    if img_bgr is None:
        raise HTTPException(status_code=400, detail="Could not decode image. Upload a valid JPG or PNG file.")

    original_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)

    # Preprocess — exact same logic as streamlit_app.py
    preprocessed = preprocess_image(original_rgb, target_size=IMG_SIZE)
    img_array = np.expand_dims(preprocessed, axis=0)  # (1, 224, 224, 3)

    # Inference — exact same logic as streamlit_app.py
    preds = model.predict(img_array, verbose=0)[0]
    pred_idx = int(np.argmax(preds))
    pred_class = CLASS_NAMES[pred_idx]
    confidence = float(preds[pred_idx])

    probabilities = {name: round(float(preds[i]), 4) for i, name in enumerate(CLASS_NAMES)}

    return {
        "prediction": pred_class,
        "confidence": round(confidence, 4),
        "probabilities": probabilities,
    }

# 🧠 Alzheimer's MRI Classification System

An ensemble deep learning system (ResNet50 + EfficientNetB3) for classifying
Alzheimer's disease severity from brain MRI scans, with Grad-CAM explainability
and a Streamlit web interface.

---

## 📋 Classes
| Class | Description |
|---|---|
| `NonDemented` | No signs of dementia |
| `VeryMildDemented` | Very early cognitive decline |
| `MildDemented` | Noticeable cognitive decline |
| `ModerateDemented` | Significant cognitive impairment |

---

## 🗂 Project Structure

```
alzheimer_ai/
├── dataset/                  ← Put OASIS dataset here
│   ├── train/
│   │   ├── MildDemented/
│   │   ├── ModerateDemented/
│   │   ├── NonDemented/
│   │   └── VeryMildDemented/
│   ├── val/
│   └── test/
├── models/
│   ├── build_model.py        ← Ensemble architecture (ResNet50 + EfficientNetB3)
│   └── gradcam.py            ← Grad-CAM visualization
├── training/
│   ├── train.py              ← Two-phase training pipeline
│   └── evaluate.py           ← Model evaluation + plots
├── preprocessing/
│   └── preprocess.py         ← CLAHE + Gaussian blur + normalization
├── utils/
│   ├── data_loader.py        ← Keras generators with augmentation
│   └── metrics.py            ← Accuracy, Precision, Recall, F1, AUC
├── app/
│   └── streamlit_app.py      ← Web application
├── saved_models/             ← Trained model checkpoints (auto-created)
├── requirements.txt
├── run_project.sh
└── README.md
```

---

## ⚡ Quick Start

### 1. Clone / Extract the project
```bash
unzip alzheimer_ai.zip
cd alzheimer_ai
```

### 2. Create virtual environment (recommended)
```bash
python3 -m venv venv
source venv/bin/activate          # Linux / macOS
# venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
# OR
bash run_project.sh install
```

### 4. Prepare the dataset
Download the **OASIS Augmented Alzheimer MRI Dataset** from Kaggle:
```
https://www.kaggle.com/datasets/uraninjo/augmented-alzheimer-mri-dataset
```
Extract and organise as:
```
dataset/
  train/  MildDemented/  ModerateDemented/  NonDemented/  VeryMildDemented/
  val/    ...
  test/   ...
```

### 5. Train the model
```bash
# Default (20 + 30 epochs)
bash run_project.sh train

# Custom settings
DATASET_DIR=dataset EPOCHS_P1=20 EPOCHS_P2=30 bash run_project.sh train

# Direct Python call
python -m training.train --dataset_dir dataset --epochs_p1 20 --epochs_p2 30
```

### 6. Evaluate
```bash
bash run_project.sh evaluate
# Outputs saved to: saved_models/eval/
```

### 7. Launch Web App
```bash
bash run_project.sh app
# Open: http://localhost:8501
```

### 8. Sanity test (no dataset required)
```bash
bash run_project.sh test
```

---

## 🏗 Model Architecture

```
Input (224×224×3)
      │
      ├──────────────────────────────┐
      │                              │
 ResNet50                     EfficientNetB3
 (pretrained ImageNet)        (pretrained ImageNet)
 include_top=False            include_top=False
      │                              │
 GlobalAveragePooling2D      GlobalAveragePooling2D
 (2048-dim)                  (1536-dim)
      │                              │
      └──────── Concatenate ─────────┘
                    │  (3584-dim)
             BatchNormalization
             Dense(512, relu, L1L2)
             BatchNormalization
             Dropout(0.6)
             Dense(256, relu)
             Dropout(0.5)
             Dense(128, relu)
             Dropout(0.4)
             Dense(4, softmax)
```

### Training Phases
| Phase | Frozen Layers | LR | Epochs |
|---|---|---|---|
| 1 | All base layers | 0.001 | 20 |
| 2 | ResNet first N-60, EfficientNet first N-50 | 0.00005 | 30 |

---

## 📊 Data Augmentation
| Parameter | Value |
|---|---|
| rotation_range | 15° |
| width_shift_range | 10% |
| height_shift_range | 10% |
| zoom_range | 10% |
| horizontal_flip | True |
| brightness_range | [0.85, 1.15] |

---

## 🌡 Grad-CAM
- Uses the last convolutional layer of ResNet50 (`conv5_block3_out`)
- Produces a class-discriminative heatmap
- Overlaid on the original MRI for visual interpretation

---

## 📁 ZIP Creation
```bash
cd ..
zip -r alzheimer_ai.zip alzheimer_ai/
```

---

## 🔧 Requirements
- Python 3.9+
- TensorFlow 2.12+
- OpenCV
- Streamlit 1.28+
- scikit-learn

---

## ⚠️ Disclaimer
This system is for **research and educational purposes only**.  
It is **not a medical device** and should not be used for clinical diagnosis.  
Always consult a qualified medical professional.

---

## 📄 License
MIT License — free to use for research and education.
